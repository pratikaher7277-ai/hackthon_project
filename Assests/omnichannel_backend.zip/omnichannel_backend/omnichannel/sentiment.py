"""Sentiment scoring for text-only channels (e.g. Instagram comments).

The default scorer is a tiny lexicon so the project runs offline. Replace it with an
LLM- or model-based scorer by implementing the SentimentScorer protocol.
"""
from __future__ import annotations

import math
import re
from typing import Optional, Protocol


class SentimentScorer(Protocol):
    def score(self, text: str) -> Optional[float]:
        """Return sentiment in [-1, 1], or None if it cannot be determined."""


_WEIGHTS = {
    "love": 2, "loved": 2, "great": 2, "amazing": 2, "excellent": 2, "awesome": 2,
    "good": 1, "helpful": 1, "fast": 1, "smooth": 1, "happy": 1, "nice": 1, "easy": 1,
    "okay": 0.3, "fine": 0.3,
    "bad": -1, "slow": -1, "confusing": -1, "late": -1, "expensive": -0.5,
    "disappointed": -1.5, "broken": -1.5, "issue": -1,
    "terrible": -2, "worst": -2, "awful": -2, "rude": -2, "hate": -2,
}
_NEGATIONS = {"not", "never", "no", "isn't", "wasn't", "don't", "didn't"}
_TOKEN = re.compile(r"[a-z']+")


class LexiconScorer:
    def score(self, text: str) -> Optional[float]:
        tokens = _TOKEN.findall((text or "").lower())
        total, matched = 0.0, 0
        for i, tok in enumerate(tokens):
            w = _WEIGHTS.get(tok)
            if w is None:
                continue
            if i > 0 and tokens[i - 1] in _NEGATIONS:
                w = -w
            total += w
            matched += 1
        if matched == 0:
            return None  # unknown, not neutral: do not invent data
        return math.tanh(total / 2.0)
