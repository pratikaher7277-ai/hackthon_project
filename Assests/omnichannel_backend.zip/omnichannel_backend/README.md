# Omnichannel Satisfaction Backend

Core backend for the "omnichannel consistency" proposal: agents scan five channels (A Instagram, B Website, C Campaigns, D Mobile App, E Blogs/Offline), an evaluator compares the data, and a chart-ready payload is served to the frontend.

- Logic and API contract: `docs/LOGIC.md`
- Evaluation and limitations: `docs/EVALUATION.md`
- Diagrams: `docs/diagrams/*.svg`

```bash
pip install -r requirements.txt
python -m omnichannel                  # demo run on simulated data
uvicorn omnichannel.api:app --reload   # API on http://localhost:8000/api/v1/report
python -m pytest -q
```

Only simulated connectors are included; see section 7 of `docs/LOGIC.md` to plug in real channels.
